#!/usr/bin/env python3
"""
analyse_folder.py
─────────────────
Analyse tous les fichiers *_Ph*.xlsx et *_Or*.xlsx d'un dossier.
Le mode est détecté automatiquement depuis le suffixe du fichier :
    *_Ph*.xlsx  →  ECRIT_IA
    *_Or*.xlsx  →  ORAL

Usage:
    python analyse_folder.py <dossier> [<filtre>]

Arguments:
    dossier  Dossier contenant les fichiers *_Ph*.xlsx et/ou *_Or*.xlsx
    filtre   Optionnel : oral | ecrit_ia | all  (défaut : all)

Modèles par défaut :
    - speaker_detection_model : deepseek
    - analysis model          : mistral_batch
"""

import sys
import os
import re
import glob
import logging
import datetime
from pathlib import Path

from ppi_analyser.core import PPIAnalyser
from ppi_analyser.config import PipelineConfig, AnalysisMode

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logging.getLogger("ppi_analyser").setLevel(logging.DEBUG)

# ── Constantes ────────────────────────────────────────────────────────────────
NOW = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

MODELS_MAPPING = {
    "deepseek":       "deepseek_deepseek",
    "mistral_batch":  "mistral_batch_mistral-large-latest",
    "gemma":          "ollama_gemma3:27b",
    "mistral_medium": "mistral_mistral-medium-2508",
    "mistral_large":  "mistral_mistral-large-2411",
    "dummy":          "dummy_dummy",
}

PROPS =[
    "Position",
    "Expansions",
    "Modifieurs",
]
PROPS = None
DETECTION_MODEL  = MODELS_MAPPING["deepseek"]
ANALYSIS_MODEL   = MODELS_MAPPING["mistral_batch"]
OUTPUT_BASE = os.path.expanduser("~/Downloads/ppi-analyser-output")

# Filtres CLI acceptés
FILTER_MAPPING: dict[str, AnalysisMode | None] = {
    "oral":     AnalysisMode.ORAL,
    "ecrit_ia": AnalysisMode.ECRIT_IA,
    "all":      None,  # None = pas de filtre
}

# Suffixes reconnus et leur mode associé
SUFFIX_MODE: dict[str, AnalysisMode] = {
    "_Ph": AnalysisMode.ECRIT_IA,
    "_Or": AnalysisMode.ORAL,
}

# ── Helpers ───────────────────────────────────────────────────────────────────
def detect_mode(filepath: str) -> AnalysisMode | None:
    """Retourne le mode correspondant au suffixe du fichier, ou None si non reconnu."""
    name = Path(filepath).name
    for suffix, mode in SUFFIX_MODE.items():
        if re.search(re.escape(suffix), name):
            return mode
    return None


def collect_files(folder: str, mode_filter: AnalysisMode | None = None) -> list[tuple[str, str, AnalysisMode]]:
    """Retourne une liste de (sentence_file, expression, mode).

    mode_filter : si fourni, ne garde que les fichiers dont le mode correspond.
    """
    patterns = [os.path.join(folder, f"*{suffix}*.xlsx") for suffix in SUFFIX_MODE]
    files = sorted({f for pattern in patterns for f in glob.glob(pattern)})
    if not files:
        suffixes = ", ".join(f"*{s}*.xlsx" for s in SUFFIX_MODE)
        raise FileNotFoundError(
            f"Aucun fichier {suffixes} trouvé dans : {folder}"
        )
    suffix_pattern = "|".join(re.escape(s) for s in SUFFIX_MODE)
    triples = []
    for f in files:
        mode = detect_mode(f)
        if mode is None:
            continue
        if mode_filter is not None and mode != mode_filter:
            continue
        expression = Path(re.split(suffix_pattern, Path(f).name)[0]).name
        triples.append((f, expression, mode))
    return triples


def analyse_file(
    sentence_file: str,
    expression: str,
    mode: AnalysisMode,
) -> None:
    analyser = PPIAnalyser(tokenization_mode="nlp")
    models = [ANALYSIS_MODEL]
    formatted_expr = expression.replace(' ', '_').replace('\'', '')
    out_dir = os.path.join(OUTPUT_BASE, f"{formatted_expr}_{NOW}")
    os.makedirs(out_dir, exist_ok=True)

    config = PipelineConfig(
        models=models,
        expression=expression,
        sentence_file=sentence_file,
        mode=mode,
        output_dir=out_dir,
        max_reqs=-1,
        start_sent=0,
        max_sentences="all",
        speaker_detection_model=DETECTION_MODEL,
        batch_mode=True,
        n_threads=8,
        batch_size=5,
        use_analysis_cache=True,
        analysis_cache_path=os.path.expanduser("~/.ppi_analyser/analysis_cache.json"),
        custom_properties=PROPS,
    )

    df, state = analyser.process_sentences(config)

    print(f"  custom_properties : {state.custom_properties_list}")
    print(f"  tokens in  : {state.total_tokens_in}")
    print(f"  tokens out : {state.total_tokens_out}")
    print(f"  total      : {state.total_tokens_in + state.total_tokens_out}")


# ── Main ──────────────────────────────────────────────────────────────────────
def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    folder      = sys.argv[1]
    filter_str  = sys.argv[2].lower() if len(sys.argv) > 2 else "all"

    if not os.path.isdir(folder):
        print(f"[ERREUR] Dossier introuvable : {folder}", file=sys.stderr)
        sys.exit(1)

    if filter_str not in FILTER_MAPPING:
        valid = ", ".join(FILTER_MAPPING.keys())
        print(f"[ERREUR] Filtre inconnu : '{filter_str}'. Valeurs acceptées : {valid}", file=sys.stderr)
        sys.exit(1)

    mode_filter = FILTER_MAPPING[filter_str]
    triples = collect_files(folder, mode_filter)

    print(f"Dossier  : {folder}")
    print(f"Filtre   : {filter_str}")
    print(f"Détection: {DETECTION_MODEL}")
    print(f"Analyse  : {ANALYSIS_MODEL}")
    print(f"Fichiers : {len(triples)}")
    print("─" * 60)

    for sentence_file, expression, mode in triples:
        mode_label = next(k for k, v in SUFFIX_MODE.items() if v == mode).strip("_")
        print(f"\n→ {expression}  [{mode_label}]")
        print(f"  fichier : {sentence_file}")
        analyse_file(
            sentence_file=sentence_file,
            expression=expression,
            mode=mode,
        )

    print("\n✓ Toutes les expressions traitées.")


if __name__ == "__main__":
    main()
